try {
    context.setVariable('target.url', 'http://httpbin.org/get');
} catch (e) {
    throw e;
}